class card { 
    // Create the deck for UNO
    List<String> deck = new ArrayList<>();
    String[] colors = {"Red", "Blue", "Green", "Yellow"};
    String[] values = {"0", "1", "2", "3", "4", "5", "6" ,"7", "8", "9", "Skip", "Draw Two", "Draw Four"};
    List<String> player1Hand = new ArrayList<>();
    List<String> aiHand = new ArrayList<>();
    List<String> discardPile = new ArrayList<>();
    List<String> drawPile = new ArrayList<>();

    public void createDeck() {
        for (String color : colors) {
            for (String value : values) {
                deck.add(color + " " + value);
            }
        }
        Collections.shuffle(deck);
    }

    public void dealCards() {
        for (int i = 0; i < 7; i++) {
            player1Hand.add(deck.remove(0));
            aiHand.add(deck.remove(0));
        }
    }

    public void displayPlayerHand() {
        System.out.println("Player 1's hand: " + player1Hand);
    }

    public void displayAIHand() {
        System.out.println("AI's hand: " + aiHand);
    }

    public void displayFirstCard() {
        discardPile.add(deck.remove(0));
        System.out.println("First card in discard pile: " + discardPile.get(0));
    }

    public void displayDrawPile() {
        drawPile.addAll(deck);
        System.out.println("Draw pile: " + drawPile);
    }
}
  // Create the discard pile
    
  

      // //Jackson Payne
      // import java.util.Random;
      // class hand {
      //     private static final String[] colors = {"Red", "Blue", "Green", "Yellow"};
      //     private static final String[] normal = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "0"};
      //     private static final String[] special = {"Skip", "Wild", "Plus2", "Plus4"};
      //     public static String generateRandomCard() {
      //         Random random = new Random();
      //         String cards = " ";
      //         String card = "";
      //         for (int i = 0; i < 7; i++) {
      //             if (random.nextBoolean()) {
      //                 card = colors[random.nextInt(colors.length)] + " " + normal[random.nextInt(normal.length)];
      //             } else {
      //                 card = special[random.nextInt(special.length)];
      //             }
      //             cards += "Generated card: a " + card + "\n";
      //         }
      //         return cards;
      //     }
//}
//        }
  
//}
//}