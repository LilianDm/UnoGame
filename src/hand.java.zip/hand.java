import java.util.Random;
class hand {
    private static final String[] colors = {"Red", "Blue", "Green", "Yellow"};
    private static final String[] normal = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "0"};
    private static final String[] special = {"Skip", "Wild", "Plus2", "Plus4"};
    public static String generateRandomCard() {
        Random random = new Random();
        String cards = " ";
        String card = "";
        for (int i = 0; i < 7; i++) {
            if (random.nextBoolean()) {
                card = colors[random.nextInt(colors.length)] + " " + normal[random.nextInt(normal.length)];
            } else {
                card = special[random.nextInt(special.length)];
            }
            cards += "Generated card: a " + card + "\n";
        }
        return cards;
    }
}