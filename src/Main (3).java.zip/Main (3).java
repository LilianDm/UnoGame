//Jackson Payne
// import java.util.ArrayList;
// import java.util.Collections;
// import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to Unus Online!");
        System.out.println("To play, press anything");
        String userInput = scanner.nextLine();
      if(userInput.equals("1")) {
        // Display image of unus cards
        System.out.println(hand.generateRandomCard());
      } else {
        System.out.println(hand.generateRandomCard());
        // WE NEED A BOOLEAN 
      }
        scanner.close();
    }
}